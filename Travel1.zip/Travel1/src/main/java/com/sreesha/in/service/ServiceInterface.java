package com.sreesha.in.service;

import java.util.List;

//import com.sreesha.in.model.Employee;
import com.sreesha.in.model.Travel;

public interface ServiceInterface {
	
	//public Integer saveEmployee(Employee employee);
	
	//public List<Employee> getAllEmp();
	
	//public void deleteEmp(Integer id);

	public Integer saveTravel(Travel travel);

	//public List<Travel> getAllEmp();

	//public void deleteEmp(Integer id);

	//public Integer saveEmp(Travel travel);

	public Integer saveTrav(Travel travel);

	public List<Travel> getAllTrav();

	public void deleteTrav(String email);

//	public void deleteTrav(Integer id);

//	public Integer saveEmp(Travel travel);

}
