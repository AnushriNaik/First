package com.sreesha.in;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelW {
	public static void main(String[] args) {
		SpringApplication.run(TravelW.class, args);
	}

}
