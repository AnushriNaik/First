package com.sreesha.in.repo;

import org.springframework.data.jpa.repository.JpaRepository;

//import com.sreesha.in.model.Employee;
import com.sreesha.in.model.Travel;

public interface TravelRepository extends JpaRepository<Travel, Integer> {

}
