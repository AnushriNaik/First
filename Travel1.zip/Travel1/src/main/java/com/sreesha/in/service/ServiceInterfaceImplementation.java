package com.sreesha.in.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sreesha.in.model.Travel;
import com.sreesha.in.repo.TravelRepository;

@Service
public class ServiceInterfaceImplementation implements ServiceInterface {
	
	@Autowired
	private TravelRepository repo;
	public Integer saveTravel(Travel travel) {
		travel = repo.save(travel);
        return travel.getId();
	}


	public List<Travel> getAllTravel() {
		return repo.findAll();
	}


	public Integer saveTrav(Travel travel) {
		// TODO Auto-generated method stub
		return null;
	}


	public List<Travel> getAllTrav() {
		// TODO Auto-generated method stub
		return null;
	}


	public void deleteTrav(String email) {
		// TODO Auto-generated method stub
		
	}


	

}